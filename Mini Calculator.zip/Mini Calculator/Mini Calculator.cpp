// Mini Calculator
//

#include <iostream>
#include <math.h>
#include <cmath>
using namespace std;

float pi = 3.14;

void startScreen();
void endScreen();
void mainMenu();

// Circle Calculations
void circleCalculations();
void circleAreaCalculations();
void circleCircumferenceCalculations();

//Arithmetic Calculations
void arithmeticCalculations();
void additionCalculations();
void subtractionCalculations();
void multiplicationCalculations();
void divisionCalculations();

//Triangle Calculations
void triangleCalculations();

//Trigonometry Calculations
void trigonometryCalculations();

//Trigonometry Side Calculations
void trigonometrySideCalculations();

//Sin Calculations
void trigonometrySinSideCalculation();
void trigonometrySinHypotenuseSideCalculation();
void trigonometrySinOppositeSideCalculation();

//Cos Calculations
void trigonometryCosSideCalculation();
void trigonometryCosAdjacentSideCalculation();
void trigonometryCosHypotenuseSideCalculation();

//Tan Calculations
void trigonometryTanSideCalculation();
void trigonometryTanAdjacentSideCalculation();
void trigonometryTanOppositeSideCalculation();

//Trigonometry Angle Calculations
void trigonometryAngleCalculations();
void trigonometrySinAngleCalculation();
void trigonometryCosAngleCalculation();
void trigonometryTanAngleCalculation();


//Pythagoras Calculations
void pythagorasCalculations();
void pythagorasAdjacentCalculations();
void pythagorasHypotenuseCalculations();
void pythagorasOppositeCalculations();


bool gameOver = false;
bool gamePlayAgain = false;
char tryAgain;

int main()
{
    startScreen();
 
    mainMenu();

    endScreen();

    return 0;
}

// Menus
void startScreen()
{
    cout << " ---------- Welcome ----------";
}
void endScreen()
{
    cout << "\n\n ---------- Goodbye ----------\n\n";
}
void mainMenu()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Option Menu ----------";
        cout << "\n\n Please Select the Program to run";
        cout << "\n 1: Arithmetic Calculations";
        cout << "\n 2: Circle Calculations";
        cout << "\n 3: Triangle Calculations";
        cout << "\n 4: Pythagoras Calculations";
        cout << "\n 5: Trigonometry Calculations";
        cout << "\n 6: Exit Program\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                arithmeticCalculations();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                circleCalculations();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                triangleCalculations();
                gameOver = false;
            }
            if (playableProgram == 4)
            {
                pythagorasCalculations();
                gameOver = false;
            }
            if (playableProgram == 5)
            {
                trigonometryCalculations();
                gameOver = false;
            }
            if (playableProgram == 6)
            {
                gameOver = true;
            }
        }
    }
}

//Circle Calculations
void circleCalculations()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Circle Calculations ----------";
        cout << "\n\n Please Select the Calculations to run:";
        cout << "\n 1: Area Calculations";
        cout << "\n 2: Circumference Calculations";
        cout << "\n 3: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                circleAreaCalculations();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                circleCircumferenceCalculations();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                gameOver = true;
            }
        }
    }
}
void circleAreaCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float radius;

        cout << "\n\n Enter radius: ";

        cin >> radius;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n " << radius << " x " << radius << " x " << pi << " = " << radius * radius * pi;
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void circleCircumferenceCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float radius;

        cout << "\n\n Enter radius: ";

        cin >> radius;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n 2 x " << pi << " x " << radius << " = " << 2 * pi * radius;
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}

//Arithmetic Calculations
void arithmeticCalculations()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Arithmetic Calculations ----------";
        cout << "\n\n Please Select the Calculations to run:";
        cout << "\n 1: Addition Calculations";
        cout << "\n 2: Subtraction Calculations";
        cout << "\n 3: Multilication Calculations";
        cout << "\n 4: Division Calculations";
        cout << "\n 5: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                additionCalculations();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                subtractionCalculations();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                multiplicationCalculations();
                gameOver = false;
            }
            if (playableProgram == 4)
            {
                divisionCalculations();
                gameOver = false;
            }
            if (playableProgram == 5)
            {
                gameOver = true;
            }
        }
    }
}
void additionCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float valueA;
        float valueB;

        cout << "\n\n Enter first number: ";

        cin >> valueA;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter second number: ";

            cin >> valueB;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n " << valueA << " + " << valueB << " = " << valueA + valueB;
            }
        }
        
        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void subtractionCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float valueA;
        float valueB;

        cout << "\n\n Enter first number: ";

        cin >> valueA;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter second number: ";

            cin >> valueB;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n " << valueA << " - " << valueB << " = " << valueA - valueB;
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void multiplicationCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float valueA;
        float valueB;

        cout << "\n\n Enter first number: ";

        cin >> valueA;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter second number: ";

            cin >> valueB;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n " << valueA << " x " << valueB << " = " << valueA * valueB;
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void divisionCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float valueA;
        float valueB;

        cout << "\n\n Enter first number: ";

        cin >> valueA;

        if (cin.fail())
        {
            cout << "\nInvalid Input";
            cout << "\nPlease try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter second number: ";

            cin >> valueB;

            if (cin.fail())
            {
                cout << "\n Invalid Input";
                cout << "\n Please try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n " << valueA << " / " << valueB << " = " << valueA / valueB;
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}

//Triangle Calculations
void triangleCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float height;
        float base;

        cout << "\n\n Enter height: ";

        cin >> height;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter base: ";

            cin >> base;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n 1/2 x " << height << " x " << base << " = " << 0.5 * height * base;
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}

//Trigonometry Calculations
void trigonometryCalculations()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Trigonometry Calculations ----------";
        cout << "\n\n Please Select the Calculations to run:";
        cout << "\n 1: Side Calculations";
        cout << "\n 2: Angle Calculations";
        cout << "\n 3: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                trigonometrySideCalculations();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                trigonometryAngleCalculations();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                gameOver = true;
            }
        }
    }
}

//Trigonometry Side Calculations
void trigonometrySideCalculations()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Trigonometry Side Calculations ----------";
        cout << "\n\n Please Select the Calculations to run:";
        cout << "\n 1: Adjacent Side Calculation";
        cout << "\n 2: Hypotenuse Side Calculation";
        cout << "\n 3: Opposite Side Calculation";
        cout << "\n 4: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                trigonometrySinSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                trigonometryCosSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                trigonometryTanSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 4)
            {
                gameOver = true;
            }
        }
    }
}

//Trigonometry Sin Calculations
void trigonometrySinSideCalculation()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Trigonometry Sin Side Calculations ----------";
        cout << "\n\n Please Select the side being used:";
        cout << "\n 1: Opposite";
        cout << "\n 2: Hypotenuse";
        cout << "\n 3: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                trigonometryTanOppositeSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                trigonometryCosHypotenuseSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                gameOver = true;
            }
        }
    }
}
void trigonometrySinOppositeSideCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float opposite;
        float degrees;
        float radians;

        cout << "\n\n Enter the Opposite: ";

        cin >> opposite;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Degrees: ";

            cin >> degrees;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                radians = degrees * (pi / 180);

                cout << "\n " << opposite << " / " << sin(radians) << " = " << opposite / sin(radians) ;
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void trigonometrySinHypotenuseSideCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float hypotenuse;
        float degrees;
        float radians;

        cout << "\n\n Enter the Hypotenuse: ";

        cin >> hypotenuse;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Degrees: ";

            cin >> degrees;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                radians = degrees * (pi / 180);

                cout << "\n " << hypotenuse << " * " << sin(radians) << " = " << hypotenuse * sin(radians);
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}

//Trigonometry Cos Calculations
void trigonometryCosSideCalculation()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Trigonometry Cos Side Calculations ----------";
        cout << "\n\n Please Select the side being used:";
        cout << "\n 1: Adjacent";
        cout << "\n 2: Hypotenuse";
        cout << "\n 3: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                trigonometryTanAdjacentSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                trigonometrySinHypotenuseSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                gameOver = true;
            }
        }
    }
}
void trigonometryCosAdjacentSideCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float adjacent;
        float degrees;
        float radians;

        cout << "\n\n Enter the Adjacent: ";

        cin >> adjacent;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Degrees: ";

            cin >> degrees;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                radians = degrees * (pi / 180);

                cout << "\n " << adjacent << " / " << cos(radians) << " = " << adjacent / cos(radians);
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void trigonometryCosHypotenuseSideCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float hypotenuse;
        float degrees;
        float radians;

        cout << "\n\n Enter the Hypotenuse: ";

        cin >> hypotenuse;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Degrees: ";

            cin >> degrees;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                radians = degrees * (pi / 180);

                cout << "\n " << hypotenuse << " x " << cos(radians) << " = " << hypotenuse * cos(radians);
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}

//Trigonometry Tan Calculations
void trigonometryTanSideCalculation()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Trigonometry Tan Side Calculations ----------";
        cout << "\n\n Please Select the side being used:";
        cout << "\n 1: Opposite";
        cout << "\n 2: Adjacent";
        cout << "\n 3: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                trigonometrySinOppositeSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                trigonometryCosAdjacentSideCalculation();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                gameOver = true;
            }
        }
    }
}
void trigonometryTanOppositeSideCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float opposite;
        float degrees;
        float radians;

        cout << "\n\n Enter the Opposite: ";

        cin >> opposite;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Degrees: ";

            cin >> degrees;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                radians = degrees * (pi / 180);

                cout << "\n " << opposite << " / " << tan(radians) << " = " << opposite / tan(radians);
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void trigonometryTanAdjacentSideCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float adjacent;
        float degrees;
        float radians;

        cout << "\n\n Enter the Adjacent: ";

        cin >> adjacent;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Degrees: ";

            cin >> degrees;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                radians = degrees * (pi / 180);

                cout << "\n " << adjacent << " x " << tan(radians) << " = " << adjacent * tan(radians);
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}

//Trigonometry Angle Calculations
void trigonometryAngleCalculations()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Trigonometry Angle Calculations ----------";
        cout << "\n\n Please Select the Calculations to run:";
        cout << "\n 1: Opposite & Hypotenuse Angle Calculation";
        cout << "\n 2: Adjacent & Hypotenuse Angle Calculation";
        cout << "\n 3: Opposite & Adjacent Angle Calculation";
        cout << "\n 4: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                trigonometrySinAngleCalculation();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                trigonometryCosAngleCalculation();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                trigonometryTanAngleCalculation();
                gameOver = false;
            }
            if (playableProgram == 4)
            {
                gameOver = true;
            }
        }
    }
}
void trigonometrySinAngleCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float opposite;
        float hypotenuse;
        float radians;

        cout << "\n\n Enter the Opposite: ";

        cin >> opposite;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Hypotenuse: ";

            cin >> hypotenuse;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n sin^-1(" << opposite << " / " << hypotenuse << ") = " << asin(opposite / hypotenuse);
                cout << "\n Degrees = " << ((asin(opposite / hypotenuse)) / (pi / 180));
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void trigonometryCosAngleCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float adjacent;
        float hypotenuse;
        float radians;

        cout << "\n\n Enter the Adjacent: ";

        cin >> adjacent;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Hypotenuse: ";

            cin >> hypotenuse;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n cos^-1(" << adjacent << " / " << hypotenuse << ") = " << acos(adjacent / hypotenuse);
                cout << "\n Degrees = " << ((acos(adjacent / hypotenuse)) / (pi / 180));
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void trigonometryTanAngleCalculation()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float opposite;
        float adjacent;
        float radians;

        cout << "\n\n Enter the Opposite: ";

        cin >> opposite;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Adjacent: ";

            cin >> adjacent;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n tan^-1(" << opposite << " / " << adjacent << ") = " << atan(opposite / adjacent);
                cout << "\n Degrees = " << ((atan(opposite / adjacent)) / (pi / 180));
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}

//Pythagoras Calculations
void pythagorasCalculations()
{
    int playableProgram;
    while (!gameOver)
    {
        cout << "\n\n ---------- Pythagoras Calculations ----------";
        cout << "\n\n Please Select the Calculation to run:";
        cout << "\n 1: Hypotenuse Side Calculation";
        cout << "\n 2: Opposite Side Calculation";
        cout << "\n 3: Adjacent Side Calculation";
        cout << "\n 4: Go Back\n";

        cin >> playableProgram;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        }
        else
        {
            if (playableProgram == 1)
            {
                pythagorasHypotenuseCalculations();
                gameOver = false;
            }
            if (playableProgram == 2)
            {
                pythagorasOppositeCalculations();
                gameOver = false;
            }
            if (playableProgram == 3)
            {
                pythagorasAdjacentCalculations();
                gameOver = false;
            }
            if (playableProgram == 4)
            {
                gameOver = true;
            }
        }
    }
}
void pythagorasAdjacentCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float opposite;
        float hypotenuse;

        cout << "\n\n Enter the Opposite: ";

        cin >> opposite;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Hypotenuse: ";

            cin >> hypotenuse;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n sqrt(" << hypotenuse << "^2 - " << opposite << "^2) = " << (sqrt(((hypotenuse * hypotenuse)) - (opposite * opposite)));
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void pythagorasHypotenuseCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float opposite;
        float adjacent;

        cout << "\n\n Enter the Opposite: ";

        cin >> opposite;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Adjacent: ";

            cin >> adjacent;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n sqrt(" << adjacent << "^2 + " << opposite << "^2) = " << (sqrt(((adjacent * adjacent)) + (opposite * opposite)));
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}
void pythagorasOppositeCalculations()
{
    while (!gameOver)
    {
        gamePlayAgain = false;

        float adjacent;
        float hypotenuse;
    
        cout << "\n\n Enter the Adjacent: ";

        cin >> adjacent;

        if (cin.fail())
        {
            cout << "\n Invalid Input";
            cout << "\n Please try again";

            // get rid of failure state
            cin.clear();

            // Clears state
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
        else
        {
            cout << "\n Enter the Hypotenuse: ";

            cin >> hypotenuse;

            if (cin.fail())
            {
                cout << "\nInvalid Input";
                cout << "\nPlease try again";

                // get rid of failure state
                cin.clear();

                // Clears state
                cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else
            {
                cout << "\n sqrt(" << hypotenuse << "^2 - " << adjacent << "^2) = " << (sqrt(((hypotenuse * hypotenuse)) - (adjacent * adjacent)));
            }
        }

        while (!gamePlayAgain)
        {
            cout << "\n\nDo you want to try again: Y/N \n";

            cin >> tryAgain;

            if (tryAgain == 'n' || tryAgain == 'N')
            {
                gameOver = true;
                gamePlayAgain = true;
            }

            else
            {
                if (tryAgain == 'y' || tryAgain == 'Y')
                {
                    gameOver = false;
                    gamePlayAgain = true;
                }

                // Illegal Character
                else
                {
                    cout << "\nIllegal character please type again";
                    gamePlayAgain = false;
                }
            }
        }
    }
}